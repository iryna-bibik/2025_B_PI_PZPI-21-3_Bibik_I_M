Run the development server:

```bash
npm install --legacy-peer-deps

npm run dev
```

Run the production server:

```bash
npm install --legacy-peer-deps

npm run build

npm run start
```

need to have .env file with variables:

GOOGLE_CLIENT_ID

GOOGLE_CLIENT_SECRET

NEXT_PUBLIC_API_BASE_URL

NEXTAUTH_SECRET

NEXTAUTH_URL
