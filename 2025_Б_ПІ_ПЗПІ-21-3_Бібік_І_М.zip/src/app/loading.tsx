import { MainLoader } from '@/components/MainLoader';

export default function Loading() {
	return <MainLoader />;
}
