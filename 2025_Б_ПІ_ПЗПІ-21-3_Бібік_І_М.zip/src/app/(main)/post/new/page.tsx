import { CreatePostForm } from '@/app/(main)/post/new/CreatePostForm';

export default function Page() {
	return (
		<div className='container mx-auto'>
			<CreatePostForm />
		</div>
	);
}
