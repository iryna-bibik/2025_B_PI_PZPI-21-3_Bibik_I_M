import { EditPostForm } from './EditPostForm';

export default function Page() {
	return (
		<div className='container mx-auto'>
			<EditPostForm />
		</div>
	);
}
