import { PostCard } from "./PostCard";


export default function Page() {
    return <div>
        <PostCard />
    </div>;
}
