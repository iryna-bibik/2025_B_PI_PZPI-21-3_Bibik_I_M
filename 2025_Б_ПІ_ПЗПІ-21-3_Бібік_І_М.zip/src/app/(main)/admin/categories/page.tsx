import { CategoryList } from "./CategoryList";

export default function Page() {
	return (
		<div className='container py-1'>
			<CategoryList />
		</div>
	);
}
